#!/bin/bash 

python immediatestart.py && delayedstart.py 

